define([], () => {
  'use strict';

  class AppModule {
  }
  
  return AppModule;
});
