define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class onList extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $variables } = context;

      const callFunctionResult = await $page.functions.check(($page.variables.currentSelection ? $page.variables.currentSelection:'') +($page.variables.rowData.length === 0 ?'' :JSON.stringify ($page.variables.rowData)));
    }
  }

  return onList;
});
