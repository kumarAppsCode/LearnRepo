define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TableSelectedChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any[]} params.keys 
     * @param {any} params.selected 
     */
    async run(context, { keys, selected }) {
      const { $page, $flow, $application, $variables } = context;

      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.rowData',
        ],
      });

      const selectedChangedListenerJs = await $page.functions.selectedChangedListener(selected);

      $page.variables.currentSelection = selectedChangedListenerJs;

      const isSelectionEmptyJs = await $page.functions.isSelectionEmpty(selected);
      $page.variables.disableDeselectAll=isSelectionEmptyJs;

      if (!selected.row.isAddAll()) {
        const getRowsForIDsJs = await $page.functions.getRowsForIDs(document.getElementById('table'), Array.from($variables.selected.row.values()));

        $page.variables.rowData = getRowsForIDsJs;
      }
    }
  }

  return TableSelectedChangeChain;
});
