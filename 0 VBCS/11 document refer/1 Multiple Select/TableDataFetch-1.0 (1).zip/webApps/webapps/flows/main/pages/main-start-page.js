define(["knockout", "ojs/ojkeyset"], (ko, keySet) => {
  'use strict';

  class PageModule {

    constructor() {
      this.selectedRows = ko.observable(new keySet.KeySetImpl());
    }

// ====================
    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    selectedChangedListener(selected) {
      let selectionText = "";

      if(selected.row.isAddAll()){
            let iterator = selected.row.deletedValues();
          // 
            iterator.forEach(function(key) {
              selectionText = selectionText.length === 0 ? key : selectionText + ", " + key;
            });
          // 
            if (iterator.size > 0) {
              selectionText = "All rows are selected except for row key(s): " + selectionText;
            } else {
              selectionText = "All rows are selected";
            }
      }else{
          if (selected.row.values().size > 0) {
            selected.row.values().forEach(function(key) {
              selectionText += selectionText.length === 0 ? key : ", " + key;
            });
            // Create a message for the selected rows
            selectionText = "Selected row key(s): " + selectionText;
          }
      }
      return selectionText;
    }
// ====================
        isSelectionEmpty(selection) {
            let row = selection.row;
            let flag=true;
            if (row.isAddAll()) {
                // return false; 
                flag=false;
            } else {
              flag=true;
              //  return true;
                // return row.values().size === 0; // If nothing is selected, it's empty.
            }
           return flag; 
        }
// ====================
        getRowsForIDs(table, rowIDs) {
            let index = 0;
            let result = [];
            while (index < 1000) {
                let row = table.getDataForVisibleRow(index);
                if (row === null) {
                    return result; 
                }
                const match = rowIDs.indexOf(row.data.property_id);
                if (match > -1) {
                    rowIDs.splice(match, 1);
                    result.push(row.data);
                    if (rowIDs.length === 0) {
                        return result; 
                    }
                }
                index++;
            }
            return result; 
        }


// ===================
        getSelectedRows() {
            return this.selectedRows;
        }
// ===================
       deselectAll() {
            this.selectedRows(new keySet.KeySetImpl());
        }
// ===================
    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    sekectDataJs(rowData) {

      console.log("DATA==>"+JSON.stringify(rowData) );

    }
  }
  
  return PageModule;
});
