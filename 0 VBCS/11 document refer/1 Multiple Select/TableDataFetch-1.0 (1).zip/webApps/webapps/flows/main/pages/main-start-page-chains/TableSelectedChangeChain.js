define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TableSelectedChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any[]} params.keys 
     * @param {any} params.selected 
     */
    async run(context, { keys, selected }) {
      const { $page, $flow, $application } = context;

      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.rowData',
        ],
      });

      const currentSelectJs = await $page.functions.selectedChangedListener(selected);

      $page.variables.currentSelection = currentSelectJs;

      const selectJsResult = await $page.functions.isSelectionEmpty(selected);

      $page.variables.disableDeselectAll = selectJsResult;

      if ((!selected.row.isAddAll())) {
        const rowJsResult = await $page.functions.getRowsForIDs(document.getElementById('multipleTableId'), Array.from(selected.row.values()));

        $page.variables.rowData = rowJsResult;
      }
    }
  }

  return TableSelectedChangeChain;
});
