define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
  'ojs/ojkeyset'
], (
  ActionChain,
  Actions,
  ActionUtils,
  keySet
) => {
  'use strict';

  class initializeVariables extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      $page.variables.selectedRows = { "row": new keySet.KeySetImpl(), "column": new keySet.KeySetImpl() };

    }
  }

  return initializeVariables;
});
