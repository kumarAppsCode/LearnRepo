define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    pageJs(arg1) {

      console.log("DATA==>"+JSON.stringify(arg1) );

    }
  }
  
  return PageModule;
});
