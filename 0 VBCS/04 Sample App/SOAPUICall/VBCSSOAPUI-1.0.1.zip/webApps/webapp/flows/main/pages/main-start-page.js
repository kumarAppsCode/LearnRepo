define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    biReportFunction(p_code) {
      let payload='<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:pub="http://xmlns.oracle.com/oxp/service/PublicReportService">'
   +'<soap:Header/>'
   +'<soap:Body>'
   +'   <pub:runReport>'
   + '     <pub:reportRequest>'
   +   '      <pub:attributeFormat>csv</pub:attributeFormat>'
   +     '    <pub:parameterNameValues>'
   +       '     <pub:item>'
   +        '       <pub:name>p_code</pub:name>'
   +         '      <pub:values>'
   +          '        <pub:item>'+p_code+'</pub:item>'
   +           '    </pub:values>'
   +           ' </pub:item>'
   +        ' </pub:parameterNameValues>'
   +        ' <pub:reportAbsolutePath>Custom/Integration Report/VBCS_TASK/Reports/VBCS Country.xdo</pub:reportAbsolutePath>'
   +        ' <pub:sizeOfDataChunkDownload>-1</pub:sizeOfDataChunkDownload>'
   +      '</pub:reportRequest>'
   +    ' </pub:runReport>'
   +  '</soap:Body>'
   +  '</soap:Envelope>';
      
console.log("payload==>"+payload);

return payload;


    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    readBIReportDataJs(response) {

      const parser= new DOMParser();

      // const xmlDoc= parser.parseFromString(response, "text/plain;charset=UTF-8");
      const xmlDoc= parser.parseFromString(response, "text/xml");
      // console.log("==>"+xmlDoc);
      const base64ReportByte=xmlDoc.querySelector("reportBytes").textContent;
      // console.log("64==>"+base64ReportByte);
      const base64DecodeReportData=atob(base64ReportByte);
      // console.log("base64 v2==>"+base64DecodeReportData);

      const data =base64DecodeReportData.split("\n");
      // const title =["LOOKUP_CODE", "LOOKUP_NAME"];
      const title =["lookupcode", "lookupname"];
      const jsonArray=data.slice(1).map(line =>{
        const value=line.split(",");
        return title.reduce(
          (obj, title, index)=>((obj[title]=value[index]),obj),
          {}
        
        );
      });

    // console.log("final==>"+JSON.stringify(jsonArray));

    return jsonArray;

    // return new ArrayDataProvider(jsonArray, {
    //   keyAttributes:'lookupcode'
    // });

    }
  }
  
  return PageModule;
});
