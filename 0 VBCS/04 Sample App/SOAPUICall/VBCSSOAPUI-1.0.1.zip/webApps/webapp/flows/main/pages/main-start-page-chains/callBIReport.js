define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class callBIReport extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      // biRequestPayload
      const callFunctionResult = await $page.functions.biReportFunction($page.variables.p_code===undefined?'':$page.variables.p_code);

      const callRestBIReportResult = await Actions.callRest(context, {
        endpoint: 'BIReport/getExternalReportWSSServiceCountry',
        body: callFunctionResult,
      });

      // readBIReportData
      const callFunction2Result = await $page.functions.readBIReportDataJs(callRestBIReportResult.body);

      $page.variables.biReportADP.data = callFunction2Result;
    }
  }

  return callBIReport;
});
