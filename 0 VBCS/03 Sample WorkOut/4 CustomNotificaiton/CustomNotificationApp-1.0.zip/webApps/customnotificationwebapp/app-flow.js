define([], () => {
  'use strict';

  class AppModule {
  }

  AppModule.prototype.fireNotification = function (notificationTitle, notificationMessage, notificationType, notificationDelay,notificationFrom,notificationAlign) {

    let finalNotificationType = notificationType.toLowerCase();
    let notificationIcon;

    switch (finalNotificationType) {
      case "error":
        finalNotificationType = "danger";
        notificationIcon = "fa-solid fa-circle-exclamation";
        break;
      case "success":
        finalNotificationType = "success";
        notificationIcon = "fa-solid fa-check";
        break;
      case "warning":
        finalNotificationType = "warning";
        notificationIcon = "fa-solid fa-triangle-exclamation";
        break;
      case "information":
        finalNotificationType = "info";
        notificationIcon = "fa-solid fa-circle-info";
        break;
      case "info":
        finalNotificationType = "info";
        notificationIcon = "fa-solid fa-circle-info";
        break;
    }


    notifyJquery.notify({
      // options
      title: '<strong>' + notificationTitle + '</strong>',
      message: notificationMessage,
      icon: notificationIcon,
      //url: 'https://www.google.com.eg/',
      target: '_blank'
    },
      {
        // settings
        element: 'body',
        //position: null,
        type: finalNotificationType,
        //allow_dismiss: true,
        //newest_on_top: false,
        showProgressbar: false,
        placement: {
          from: notificationFrom,
          align: notificationAlign
        },
        offset: 20,
        spacing: 10,
        z_index: 1031,
        delay: notificationDelay,
        timer: 1000,
        url_target: '_blank',
        mouse_over: null,
        animate: {
          enter: 'animated fadeInDown',
          exit: 'animated fadeOutRight'
        },
        onShow: null,
        onShown: null,
        onClose: null,
        onClosed: null,
        icon_type: 'class'
      });
  };

  return AppModule;
});
