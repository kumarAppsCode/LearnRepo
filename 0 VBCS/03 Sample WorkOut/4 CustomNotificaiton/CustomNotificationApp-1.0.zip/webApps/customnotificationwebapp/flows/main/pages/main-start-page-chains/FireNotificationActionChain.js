define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class FireNotificationActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.title 
     * @param {string} params.message 
     * @param {string} params.delay 
     * @param {string} params.type 
     * @param {string} params.from 
     * @param {string} params.align 
     */
    async run(context, { title, message, delay, type, from, align }) {
      const { $page, $flow, $application } = context;

      const callFunctionResult = await $application.functions.fireNotification(title, message, type, delay, from, align);
    }
  }

  return FireNotificationActionChain;
});
