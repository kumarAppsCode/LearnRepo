/**
 * Copyright (c)2023, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 */

// Import the functions you need from the SDKs you need
importScripts("https://www.gstatic.com/firebasejs/9.22.0/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/9.22.0/firebase-messaging-compat.js");

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
 const firebaseConfig = {
        apiKey: "AIzaSyDSUsTtvN5kLZzaxrFoV9rVpZNXbUYeuw0",
        authDomain: "push-notification-8f4e7.firebaseapp.com",
        projectId: "push-notification-8f4e7",
        storageBucket: "push-notification-8f4e7.appspot.com",
        messagingSenderId: "546977256841",
        appId: "1:546977256841:web:41b40c1b683dd9ded17d58"
      };

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

const messaging = firebase.messaging();

var eventId;

const focusOrOpen = function(event, url) {
    const urlToOpen = new URL(url, self.location.origin).href;

    const promiseChain = clients.matchAll({
      type: 'window',
      includeUncontrolled: true
    })
    .then((windowClients) => {
      let matchingClient = null;

      for (let i = 0; i < windowClients.length; i++) {
        const windowClient = windowClients[i];
        if (urlToOpen.startsWith(windowClient.url)) {
          matchingClient = windowClient;
          break;
        }
      }

      if (matchingClient) {
        // could just focus it if query params are the same:
        // matchingClient.focus();
        // unfortunately below call does not work: sw cannot change URL
        // return matchingClient.navigate(urlToOpen);
        return clients.openWindow(urlToOpen);
      } else {
        return clients.openWindow(urlToOpen);
      }
    });

    event.waitUntil(promiseChain);  
};

messaging.onBackgroundMessage((payload) => {
  // Customize notification here
  const notificationTitle = ''+payload.notification.title;
  const notificationOptions = {
    body: "New event was created. Click to learn more about it."
  };
  // eventId = payload.notification.eventId;
  return self.registration.showNotification(notificationTitle, notificationOptions);

});


self.addEventListener('notificationclick', function(event) {
  const clickedNotification = event.notification;
  clickedNotification.close();
  // TODO: update "your-vb-instance-here"
  // TODO: update rt/Local_Events/1.0/webApps/events to match your app
  //       rt is for staged app
  //       1.0 is version of the app
  //       "events" is web app name
  focusOrOpen(event, "https://your-vb-instance-here/ic/builder/rt/Local_Events/1.0/webApps/events/?eventId="+eventId+"&page=shell&shell=main&main=main-event");
});
