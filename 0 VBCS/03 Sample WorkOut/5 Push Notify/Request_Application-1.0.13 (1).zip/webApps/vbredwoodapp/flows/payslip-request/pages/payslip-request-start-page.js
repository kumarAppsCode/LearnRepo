define([],function(){
  'use strict';
 
 var PageModule = function PageModule() {};

PageModule.prototype.download = function(){
      

      html2canvas.toPng(document.getElementById('content2'))
        .then(function (blob) {
            var pdf = new jsPDF('l', 'pt', [$('#content2').width(), $('#content2').height()]);
            pdf.addImage(blob, 'PNG', 0, 0, $('#content2').width(), $('#content2').height());
            pdf.save("test.pdf");

        });
};

// window.jsPDF = window.jspdf.jsPDF;
PageModule.prototype.download1 = function(){ 
var doc = new jsPDF("p", "mm", "a4");
  html2canvas(document.querySelector('#content2')).then(function(canvas){
    var imgData = canvas.toDataURL('image/png');

    var imgWidth = 100 ; 
    var imgHeight = 100;

    var position = 55;

    doc.addImage(imgData, 'PNG', 55, position, imgWidth, imgHeight);

    // doc.output('dataurlnewwindow');
    doc.save("test.pdf");
  });
};        

  return PageModule;
});
// format: 'a4', orientation: 'landscape', unit: 'cm'