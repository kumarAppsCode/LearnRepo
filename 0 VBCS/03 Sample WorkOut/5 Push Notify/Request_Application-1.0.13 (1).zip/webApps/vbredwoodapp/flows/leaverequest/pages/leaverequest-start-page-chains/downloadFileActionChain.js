define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class downloadFileActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $event } = context;

      await $page.functions.downloadFileFromBase64($page.variables.attachmentObj.p_document_file, $page.variables.attachmentObj.document_name, $page.variables.attachmentObj.DOCUMENT_TYPE);
    }
  }

  return downloadFileActionChain;
});
