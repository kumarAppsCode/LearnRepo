define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class addFilesButton extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const callComponentMethodFp1FocusResult = await Actions.callComponentMethod(context, {
        selector: '#fp1',
        method: 'focus',
      });
    }
  }

  return addFilesButton;
});
