define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojListView6177735591ChangeSelectionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.approvalsId
     */
    async run(context, { approvalsId }) {
      const { $page, $flow, $application } = context;
      $page.variables.oj_list_view_617773559_1SelectedId = approvalsId;
    }
  }

  return ojListView6177735591ChangeSelectionChain;
});
