define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class onCliclApprove extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const runInParallelResult = await Promise.all([
        async () => {

          if ($page.variables.group === 'Leave') {
            await Actions.callComponentMethod(context, {
              selector: '#dia1',
              method: 'open',
            });
          }
        },
        async () => {

          if ($page.variables.group === 'PO') {
            await Actions.callComponentMethod(context, {
              selector: '#dia2',
              method: 'open',
            });
          }
        },
      ].map(sequence => sequence()));
    }
  }

  return onCliclApprove;
});
