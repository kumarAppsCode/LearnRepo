define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToGetApprovalsbyidDetailChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.getApprovalsbyidId 
     * @param {string} params.group 
     */
    async run(context, { getApprovalsbyidId, group }) {
      const { $page, $flow, $application } = context;
      const navigateToPageApprovalDetailsResult = await Actions.navigateToPage(context, {
        page: 'Approval_Details',
        params: {
          getApprovalsbyidId: getApprovalsbyidId,
          group: group,
        },
      });
    }
  }

  return navigateToGetApprovalsbyidDetailChain;
});
