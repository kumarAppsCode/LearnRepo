define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ipd1ChangeSelectionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.getApprovalsbyidId
     */
    async run(context, { getApprovalsbyidId }) {
      const { $page, $flow, $application } = context;
      $page.variables.ipd1SelectedId = getApprovalsbyidId;
    }
  }

  return ipd1ChangeSelectionChain;
});
