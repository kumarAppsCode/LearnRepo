define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadGetApprovalsbyidChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const callRestResult = await Actions.callRest(context, {
        endpoint: 'RequestApplication/getApprovalsbyid',
        responseType: 'getApprovalsbyidResponse',
        uriParams: {
          'Approvals_Id': $page.variables.getApprovalsbyidId,
        },
      }, { id: 'loadGetApprovalsbyid' });

      if (!callRestResult.ok) {
        await Actions.fireNotificationEvent(context, {
          message: 'Could not load data: status ' + callRestResult.status,
          displayMode: 'persist',
          type: 'error',
          summary: 'Could not load data',
        }, { id: 'fireErrorNotification' });

        return;
      }

      $page.variables.getApprovalsbyid = callRestResult.body;
    }
  }

  return loadGetApprovalsbyidChain;
});
