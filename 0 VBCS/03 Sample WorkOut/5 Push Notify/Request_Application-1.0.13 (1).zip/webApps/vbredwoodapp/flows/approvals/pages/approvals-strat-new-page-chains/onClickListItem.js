define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class onClickListItem extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.approvalsId 
     * @param {string} params.group 
     */
    async run(context, { approvalsId, group }) {
      const { $page, $flow, $application } = context;

      const navigateToPageApprovalsDetailResult = await Actions.navigateToPage(context, {
        page: 'approvals-detail',
        params: {
          approvalsId: approvalsId,
          group: group,
        },
      });
    }
  }

  return onClickListItem;
});
