define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class pageLoad extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const callRestOrdsServiceGetSearchAdminInvoiceResult = await Actions.callRest(context, {
        endpoint: 'OrdsService/getSearchAdminInvoice',
        uriParams: {
          'l_from_date': $page.variables.searchObj.fromDate,
          'l_to_date': $page.variables.searchObj.toDate,
        },
      });

      const callFunctionResult = await $page.functions.paginghdrdata(callRestOrdsServiceGetSearchAdminInvoiceResult.body.items);

      $page.variables.searchTable = callFunctionResult;
    }
  }

  return pageLoad;
});
