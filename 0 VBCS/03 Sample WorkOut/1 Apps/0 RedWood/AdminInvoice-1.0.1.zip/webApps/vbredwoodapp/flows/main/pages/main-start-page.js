define(['ojs/ojpagingdataproviderview','ojs/ojarraydataprovider'], 
(PagingDataProviderView,ArrayDataProvider) => {
  'use strict';

  class PageModule {


 paginghdrdata(array) {
      let data = new PagingDataProviderView(new ArrayDataProvider(
      array, {
        idAttribute: 'request_id'
        }));
      return data;
    }
// 

  }
  
  return PageModule;
});
